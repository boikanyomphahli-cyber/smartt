# Smart Pantry Manager

A Java Android app that helps users track ingredients already at home and suggests recipes only when every required ingredient is available in the pantry in a sufficient quantity.

## Technology
- Java with Android Studio
- SQLite via `SQLiteOpenHelper`
- RecyclerView with custom adapters
- Android Intents for screen navigation
- SharedPreferences for the expiry reminder preference

SQLite was selected because the assignment focuses on local pantry persistence, CRUD operations, and data that remains available after the app is closed. It also avoids requiring a network connection or backend service.

## Main features
- Add, view, edit, and delete pantry ingredients
- Save ingredient name, quantity, unit, and optional expiry date
- Preloaded collection of 18 recipes
- Strict recipe matching: all required ingredients and quantities must be available
- Recipe detail screen with ingredients and method
- Settings preference saved locally
- Input validation and an empty-suggestions message

## Requirements
- Android Studio with Android SDK 35 installed
- JDK 17 (the version supported by the Android Gradle Plugin used here)
- Internet access on first Gradle sync to download dependencies

## Run the project
1. Extract the project ZIP.
2. Open Android Studio.
3. Choose **Open** and select the `SmartPantryManager` folder (the folder containing `settings.gradle`).
4. Allow Gradle to sync and install any requested Android SDK components.
5. Create an Android emulator (API 26 or later) using Device Manager, or connect an Android phone with USB debugging enabled.
6. Press **Run** and select the app configuration/device.
7. On first launch, SQLite creates the database and seeds the recipe collection.

## Test the strict matching rule
1. Add `tomato`, quantity `2`, unit `pieces`.
2. Add `egg`, quantity `2`, unit `pieces`.
3. Open Suggested Recipes: `Tomato Egg Scramble` should appear.
4. Delete the egg ingredient or reduce its quantity below 2.
5. Open Suggested Recipes again: `Tomato Egg Scramble` must no longer appear.

Use recipe units as supplied in the seeded recipes. The app supports basic plural normalization and limited unit aliases; it does not convert between different measurement types (for example, grams and pieces).

## GitHub workflow
Create your own public repository and push this project. Make at least 10 genuine commits over the development process. Do not manufacture a commit history: use descriptive messages as you complete each actual step. Add your repository URL to the report after creating it.

## Before submission
- Test every screen and CRUD operation on your emulator/device.
- Capture real screenshots from your running app for the report.
- Record a narrated 5–7 minute video demonstrating GitHub history, app functionality, strict matching, persistence, and your understanding of the code.
- Add the video to the submission ZIP yourself. It is not included because it must show your own actual work.
