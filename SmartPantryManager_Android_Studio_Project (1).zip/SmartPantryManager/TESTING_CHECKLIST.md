# Testing checklist (complete after testing on your device)

Mark each item only after you have performed the test.

- [ ] App launches without crashing.
- [ ] Add an ingredient with valid values.
- [ ] Blank ingredient name is rejected.
- [ ] Invalid or zero quantity is rejected.
- [ ] Optional expiry date accepts YYYY-MM-DD.
- [ ] Pantry list displays saved ingredients.
- [ ] Edit an ingredient and confirm changes appear.
- [ ] Delete an ingredient after confirming the dialog.
- [ ] Close and reopen the app; pantry data remains.
- [ ] Tomato Egg Scramble appears with 2 tomatoes and 2 eggs (matching units).
- [ ] Recipe disappears if an ingredient is missing.
- [ ] Recipe disappears if a quantity is insufficient.
- [ ] Recipe detail displays ingredients and method.
- [ ] Settings preference remains after leaving and reopening Settings.
- [ ] No location or mapping services are used.
- [ ] Capture actual screenshots for the report.
- [ ] Create/push 10+ genuine commits.
- [ ] Record and include the narrated 5–7 minute video.
