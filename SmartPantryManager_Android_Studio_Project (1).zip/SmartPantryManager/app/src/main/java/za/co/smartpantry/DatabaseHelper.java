package za.co.smartpantry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "smart_pantry.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE pantry (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, expiry_date TEXT)");
        db.execSQL("CREATE TABLE recipes (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, method TEXT NOT NULL)");
        db.execSQL("CREATE TABLE recipe_ingredients (id INTEGER PRIMARY KEY AUTOINCREMENT, recipe_id INTEGER NOT NULL, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, FOREIGN KEY(recipe_id) REFERENCES recipes(id))");
        seedRecipes(db);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Database migrations should be added here when the schema changes.
    }

    private void seedRecipes(SQLiteDatabase db) {
        seed(db, "Tomato Egg Scramble", "1. Chop the tomatoes. 2. Beat the eggs. 3. Cook tomatoes in a pan, add eggs and stir until set.",
            new String[]{"tomato","egg"}, new double[]{2,2}, new String[]{"pieces","pieces"});
        seed(db, "Cheese Omelette", "1. Beat eggs. 2. Cook in a lightly oiled pan. 3. Add cheese and fold.",
            new String[]{"egg","cheese"}, new double[]{2,30}, new String[]{"pieces","g"});
        seed(db, "Garlic Tomato Pasta", "1. Boil pasta. 2. Cook garlic and tomatoes. 3. Mix with pasta.",
            new String[]{"pasta","tomato","garlic"}, new double[]{100,2,1}, new String[]{"g","pieces","cloves"});
        seed(db, "Potato and Onion Hash", "1. Dice potato and onion. 2. Fry until the potato is tender and golden.",
            new String[]{"potato","onion"}, new double[]{2,1}, new String[]{"pieces","pieces"});
        seed(db, "Banana Oat Pancakes", "1. Mash banana. 2. Mix with oats and egg. 3. Cook small pancakes on both sides.",
            new String[]{"banana","oats","egg"}, new double[]{1,50,1}, new String[]{"pieces","g","pieces"});
        seed(db, "Simple Fried Rice", "1. Scramble the egg. 2. Add cooked rice and peas. 3. Stir-fry until hot.",
            new String[]{"rice","egg","peas"}, new double[]{150,1,50}, new String[]{"g","pieces","g"});
        seed(db, "Spinach Cheese Toast", "1. Wilt spinach. 2. Place spinach and cheese on bread. 3. Toast until warm.",
            new String[]{"spinach","cheese","bread"}, new double[]{40,30,2}, new String[]{"g","g","slices"});
        seed(db, "Carrot Soup", "1. Chop carrots and onion. 2. Simmer in water until soft. 3. Blend carefully until smooth.",
            new String[]{"carrot","onion"}, new double[]{3,1}, new String[]{"pieces","pieces"});
        seed(db, "Apple Oat Bowl", "1. Chop the apple. 2. Mix with oats and milk. 3. Serve chilled or warm.",
            new String[]{"apple","oats","milk"}, new double[]{1,40,100}, new String[]{"pieces","g","ml"});
        seed(db, "Peanut Banana Toast", "1. Toast bread. 2. Spread peanut butter. 3. Add sliced banana.",
            new String[]{"bread","peanut butter","banana"}, new double[]{2,20,1}, new String[]{"slices","g","pieces"});
        seed(db, "Cucumber Tomato Salad", "1. Wash and chop cucumber and tomatoes. 2. Toss together and serve.",
            new String[]{"cucumber","tomato"}, new double[]{1,2}, new String[]{"pieces","pieces"});
        seed(db, "Garlic Spinach Pasta", "1. Boil pasta. 2. Gently cook garlic and spinach. 3. Combine and serve.",
            new String[]{"pasta","garlic","spinach"}, new double[]{100,1,40}, new String[]{"g","cloves","g"});
        seed(db, "Potato Egg Cakes", "1. Grate potato. 2. Mix with egg. 3. Pan-cook small cakes until cooked through.",
            new String[]{"potato","egg"}, new double[]{1,1}, new String[]{"pieces","pieces"});
        seed(db, "Yoghurt Fruit Bowl", "1. Slice banana and apple. 2. Add to yoghurt and serve.",
            new String[]{"banana","apple","yoghurt"}, new double[]{1,1,100}, new String[]{"pieces","pieces","g"});
        seed(db, "Pea and Carrot Rice", "1. Cook rice. 2. Steam peas and carrot. 3. Mix together.",
            new String[]{"rice","peas","carrot"}, new double[]{150,50,1}, new String[]{"g","g","pieces"});
        seed(db, "Cheese Tomato Toast", "1. Place sliced tomato and cheese on bread. 2. Toast until the cheese melts.",
            new String[]{"bread","tomato","cheese"}, new double[]{2,1,30}, new String[]{"slices","pieces","g"});
        seed(db, "Onion Cheese Scramble", "1. Soften chopped onion. 2. Add beaten eggs and cheese. 3. Stir until cooked.",
            new String[]{"onion","egg","cheese"}, new double[]{1,2,20}, new String[]{"pieces","pieces","g"});
        seed(db, "Apple Banana Smoothie", "1. Blend apple, banana and milk until smooth.",
            new String[]{"apple","banana","milk"}, new double[]{1,1,150}, new String[]{"pieces","pieces","ml"});
    }

    private void seed(SQLiteDatabase db, String name, String method, String[] names, double[] quantities, String[] units) {
        ContentValues recipe = new ContentValues();
        recipe.put("name", name); recipe.put("method", method);
        long id = db.insertWithOnConflict("recipes", null, recipe, SQLiteDatabase.CONFLICT_IGNORE);
        if (id == -1) return;
        for (int i = 0; i < names.length; i++) {
            ContentValues ingredient = new ContentValues();
            ingredient.put("recipe_id", id); ingredient.put("name", names[i]);
            ingredient.put("quantity", quantities[i]); ingredient.put("unit", units[i]);
            db.insert("recipe_ingredients", null, ingredient);
        }
    }

    public long addIngredient(String name, double quantity, String unit, String expiry) {
        ContentValues v = new ContentValues();
        v.put("name", normalize(name)); v.put("quantity", quantity); v.put("unit", normalizeUnit(unit)); v.put("expiry_date", expiry);
        return getWritableDatabase().insert("pantry", null, v);
    }

    public int updateIngredient(long id, String name, double quantity, String unit, String expiry) {
        ContentValues v = new ContentValues();
        v.put("name", normalize(name)); v.put("quantity", quantity); v.put("unit", normalizeUnit(unit)); v.put("expiry_date", expiry);
        return getWritableDatabase().update("pantry", v, "id=?", new String[]{String.valueOf(id)});
    }

    public int deleteIngredient(long id) {
        return getWritableDatabase().delete("pantry", "id=?", new String[]{String.valueOf(id)});
    }

    public List<Ingredient> getPantry() {
        List<Ingredient> items = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,name,quantity,unit,expiry_date FROM pantry ORDER BY name", null)) {
            while (c.moveToNext()) items.add(new Ingredient(c.getLong(0), c.getString(1), c.getDouble(2), c.getString(3), c.getString(4)));
        }
        return items;
    }

    public Ingredient getIngredient(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,name,quantity,unit,expiry_date FROM pantry WHERE id=?", new String[]{String.valueOf(id)})) {
            if (c.moveToFirst()) return new Ingredient(c.getLong(0), c.getString(1), c.getDouble(2), c.getString(3), c.getString(4));
        }
        return null;
    }

    public List<Recipe> getRecipes() {
        List<Recipe> recipes = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT id,name,method FROM recipes ORDER BY name", null)) {
            while (c.moveToNext()) {
                long id = c.getLong(0);
                List<Recipe.RecipeIngredient> ingredients = new ArrayList<>();
                try (Cursor ic = db.rawQuery("SELECT name,quantity,unit FROM recipe_ingredients WHERE recipe_id=?", new String[]{String.valueOf(id)})) {
                    while (ic.moveToNext()) ingredients.add(new Recipe.RecipeIngredient(ic.getString(0), ic.getDouble(1), ic.getString(2)));
                }
                recipes.add(new Recipe(id, c.getString(1), c.getString(2), ingredients));
            }
        }
        return recipes;
    }

    public List<Recipe> getSuggestedRecipes() {
        List<Recipe> suggestions = new ArrayList<>();
        List<Ingredient> pantry = getPantry();
        for (Recipe recipe : getRecipes()) {
            boolean allAvailable = true;
            for (Recipe.RecipeIngredient required : recipe.ingredients) {
                Ingredient found = findPantryIngredient(pantry, required.name);
                if (found == null || !unitsCompatible(found.unit, required.unit) || found.quantity < required.quantity) {
                    allAvailable = false;
                    break;
                }
            }
            if (allAvailable) suggestions.add(recipe);
        }
        return suggestions;
    }

    public Recipe getRecipe(long id) {
        for (Recipe recipe : getRecipes()) if (recipe.id == id) return recipe;
        return null;
    }

    private Ingredient findPantryIngredient(List<Ingredient> pantry, String wanted) {
        String target = canonical(wanted);
        for (Ingredient item : pantry) if (canonical(item.name).equals(target)) return item;
        return null;
    }

    private String canonical(String value) {
        String s = normalize(value).toLowerCase(Locale.ROOT);
        if (s.endsWith("ies") && s.length() > 4) s = s.substring(0, s.length()-3) + "y";
        else if (s.endsWith("oes") && s.length() > 4) s = s.substring(0, s.length()-2);
        else if (s.endsWith("s") && !s.endsWith("ss") && s.length() > 3) s = s.substring(0, s.length()-1);
        if (s.equals("tomatoes")) s = "tomato";
        if (s.equals("potatoes")) s = "potato";
        return s;
    }

    private boolean unitsCompatible(String pantryUnit, String recipeUnit) {
        String a = normalizeUnit(pantryUnit), b = normalizeUnit(recipeUnit);
        if (a.equals(b)) return true;
        // Simple aliases only; do not compare unlike measurement dimensions.
        return (a.equals("piece") && b.equals("pieces")) || (a.equals("pieces") && b.equals("piece"))
            || (a.equals("slice") && b.equals("slices")) || (a.equals("slices") && b.equals("slice"))
            || (a.equals("clove") && b.equals("cloves")) || (a.equals("cloves") && b.equals("clove"));
    }

    private String normalize(String s) { return s == null ? "" : s.trim().replaceAll("\\s+", " "); }
    private String normalizeUnit(String s) { return normalize(s).toLowerCase(Locale.ROOT); }
}
