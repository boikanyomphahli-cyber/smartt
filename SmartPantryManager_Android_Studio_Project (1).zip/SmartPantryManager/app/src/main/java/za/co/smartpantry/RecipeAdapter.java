package za.co.smartpantry;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.stream.Collectors;

public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.Holder> {
    public interface OnRecipeClick { void open(Recipe recipe); }
    private final List<Recipe> recipes; private final OnRecipeClick listener;
    public RecipeAdapter(List<Recipe> recipes, OnRecipeClick listener) { this.recipes=recipes; this.listener=listener; }
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int type) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.row_recipe, parent, false));
    }
    @Override public void onBindViewHolder(@NonNull Holder h, int position) {
        Recipe r=recipes.get(position); h.name.setText(r.name);
        String names = r.ingredients.stream().map(i -> i.name).collect(Collectors.joining(", "));
        h.ingredients.setText("Uses: " + names); h.itemView.setOnClickListener(v -> listener.open(r));
    }
    @Override public int getItemCount() { return recipes.size(); }
    static class Holder extends RecyclerView.ViewHolder {
        TextView name, ingredients;
        Holder(View v) { super(v); name=v.findViewById(R.id.recipeName); ingredients=v.findViewById(R.id.recipeIngredients); }
    }
}
