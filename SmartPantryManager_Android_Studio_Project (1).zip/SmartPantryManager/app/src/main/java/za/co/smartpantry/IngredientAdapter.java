package za.co.smartpantry;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class IngredientAdapter extends RecyclerView.Adapter<IngredientAdapter.Holder> {
    public interface Actions { void edit(Ingredient item); void delete(Ingredient item); }
    private final List<Ingredient> items;
    private final Actions actions;
    public IngredientAdapter(List<Ingredient> items, Actions actions) { this.items = items; this.actions = actions; }
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.row_ingredient, parent, false));
    }
    @Override public void onBindViewHolder(@NonNull Holder h, int position) {
        Ingredient item = items.get(position);
        h.name.setText(item.name);
        h.quantity.setText(item.quantity + " " + item.unit + (item.expiryDate.isEmpty() ? "" : " • Expires: " + item.expiryDate));
        h.edit.setOnClickListener(v -> actions.edit(item));
        h.delete.setOnClickListener(v -> actions.delete(item));
    }
    @Override public int getItemCount() { return items.size(); }
    static class Holder extends RecyclerView.ViewHolder {
        TextView name, quantity; Button edit, delete;
        Holder(View v) { super(v); name=v.findViewById(R.id.itemName); quantity=v.findViewById(R.id.itemQuantity); edit=v.findViewById(R.id.editButton); delete=v.findViewById(R.id.deleteButton); }
    }
}
