package za.co.smartpantry;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class SuggestedRecipesActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_suggestions);
        RecyclerView recycler=findViewById(R.id.recipesRecycler); TextView message=findViewById(R.id.suggestionMessage);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        List<Recipe> matches=new DatabaseHelper(this).getSuggestedRecipes();
        if(matches.isEmpty()) message.setText("No recipes match your pantry yet. Add more ingredients or check the quantities.");
        else message.setText(matches.size()+" recipe(s) match every required ingredient and quantity.");
        recycler.setAdapter(new RecipeAdapter(matches, recipe -> {
            Intent i=new Intent(this,RecipeDetailActivity.class); i.putExtra("recipe_id",recipe.id); startActivity(i);
        }));
    }
}
