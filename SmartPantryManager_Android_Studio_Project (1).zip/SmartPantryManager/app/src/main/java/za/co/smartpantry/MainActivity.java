package za.co.smartpantry;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper db; private RecyclerView recycler; private TextView empty;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_main);
        db = new DatabaseHelper(this); recycler=findViewById(R.id.pantryRecycler); empty=findViewById(R.id.emptyText);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        findViewById(R.id.addButton).setOnClickListener(v -> startActivity(new Intent(this, IngredientFormActivity.class)));
        findViewById(R.id.suggestionsButton).setOnClickListener(v -> startActivity(new Intent(this, SuggestedRecipesActivity.class)));
        findViewById(R.id.settingsButton).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
    }
    @Override protected void onResume() { super.onResume(); refreshPantry(); }
    private void refreshPantry() {
        List<Ingredient> items=db.getPantry(); empty.setVisibility(items.isEmpty()?TextView.VISIBLE:TextView.GONE);
        recycler.setAdapter(new IngredientAdapter(items, new IngredientAdapter.Actions() {
            @Override public void edit(Ingredient item) {
                Intent i=new Intent(MainActivity.this, IngredientFormActivity.class); i.putExtra("ingredient_id", item.id); startActivity(i);
            }
            @Override public void delete(Ingredient item) {
                new AlertDialog.Builder(MainActivity.this).setTitle("Delete ingredient")
                    .setMessage("Remove " + item.name + " from your pantry?")
                    .setNegativeButton("Cancel", null).setPositiveButton("Delete", (d,w)->{
                        db.deleteIngredient(item.id); refreshPantry(); Toast.makeText(MainActivity.this,"Ingredient deleted",Toast.LENGTH_SHORT).show();
                    }).show();
            }
        }));
    }
}
