package za.co.smartpantry;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_settings);
        SharedPreferences prefs=getSharedPreferences("preferences",MODE_PRIVATE);
        Switch expirySwitch=findViewById(R.id.expirySwitch);
        expirySwitch.setChecked(prefs.getBoolean("expiry_reminders",true));
        expirySwitch.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("expiry_reminders",checked).apply());
    }
}
