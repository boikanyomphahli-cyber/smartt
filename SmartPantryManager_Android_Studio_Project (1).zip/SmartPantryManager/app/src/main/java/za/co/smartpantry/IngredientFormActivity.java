package za.co.smartpantry;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class IngredientFormActivity extends AppCompatActivity {
    private DatabaseHelper db; private EditText name, quantity, unit, expiry; private long editId=-1;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_ingredient_form);
        db=new DatabaseHelper(this); name=findViewById(R.id.nameInput); quantity=findViewById(R.id.quantityInput);
        unit=findViewById(R.id.unitInput); expiry=findViewById(R.id.expiryInput);
        editId=getIntent().getLongExtra("ingredient_id",-1);
        if(editId!=-1) {
            TextView title=findViewById(R.id.formTitle); title.setText("Edit ingredient");
            Ingredient item=db.getIngredient(editId);
            if(item!=null){ name.setText(item.name); quantity.setText(String.valueOf(item.quantity)); unit.setText(item.unit); expiry.setText(item.expiryDate); }
        }
        findViewById(R.id.saveButton).setOnClickListener(v -> save());
    }
    private void save() {
        String n=name.getText().toString().trim(), q=quantity.getText().toString().trim(), u=unit.getText().toString().trim(), e=expiry.getText().toString().trim();
        if(n.isEmpty()){ name.setError("Enter an ingredient name"); name.requestFocus(); return; }
        if(q.isEmpty()){ quantity.setError("Enter a quantity"); quantity.requestFocus(); return; }
        if(u.isEmpty()){ unit.setError("Enter a unit"); unit.requestFocus(); return; }
        double amount;
        try { amount=Double.parseDouble(q); } catch(NumberFormatException ex){ quantity.setError("Enter a valid number"); return; }
        if(amount<=0){ quantity.setError("Quantity must be greater than zero"); return; }
        if(!e.isEmpty() && !e.matches("\\d{4}-\\d{2}-\\d{2}")){ expiry.setError("Use YYYY-MM-DD or leave blank"); return; }
        if(editId==-1) db.addIngredient(n,amount,u,e); else db.updateIngredient(editId,n,amount,u,e);
        Toast.makeText(this, editId==-1?"Ingredient added":"Ingredient updated",Toast.LENGTH_SHORT).show(); finish();
    }
}
