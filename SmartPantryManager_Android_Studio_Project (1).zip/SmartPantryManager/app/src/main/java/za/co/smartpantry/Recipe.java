package za.co.smartpantry;

import java.util.List;

public class Recipe {
    public long id;
    public String name;
    public String method;
    public List<RecipeIngredient> ingredients;

    public Recipe(long id, String name, String method, List<RecipeIngredient> ingredients) {
        this.id = id; this.name = name; this.method = method; this.ingredients = ingredients;
    }

    public static class RecipeIngredient {
        public String name;
        public double quantity;
        public String unit;
        public RecipeIngredient(String name, double quantity, String unit) {
            this.name = name; this.quantity = quantity; this.unit = unit;
        }
    }
}
