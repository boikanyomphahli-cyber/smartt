package za.co.smartpantry;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;
import java.util.stream.Collectors;

public class RecipeDetailActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_recipe_detail);
        long id=getIntent().getLongExtra("recipe_id",-1); Recipe r=new DatabaseHelper(this).getRecipe(id);
        if(r==null){ finish(); return; }
        ((TextView)findViewById(R.id.detailName)).setText(r.name);
        String ingredients=r.ingredients.stream().map(i -> "• "+i.quantity+" "+i.unit+" "+i.name).collect(Collectors.joining("\n"));
        ((TextView)findViewById(R.id.detailIngredients)).setText(ingredients);
        ((TextView)findViewById(R.id.detailMethod)).setText(r.method);
    }
}
